## Registry Tampering

Hunting for persistence techniques via registry modifications.