## Threat Hunting: Suspicious PowerShell Activity

Used logs to uncover suspicious PowerShell commands.