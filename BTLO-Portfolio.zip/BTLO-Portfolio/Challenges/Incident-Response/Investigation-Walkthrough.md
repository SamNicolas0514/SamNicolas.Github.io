## IR Walkthrough

Steps taken to investigate and contain the incident.