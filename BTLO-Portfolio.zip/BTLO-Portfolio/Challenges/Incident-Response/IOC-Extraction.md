## IOC Extraction

Collected indicators from various artifacts.