## Memory Forensics

Analysis of memory image using Volatility and Redline.