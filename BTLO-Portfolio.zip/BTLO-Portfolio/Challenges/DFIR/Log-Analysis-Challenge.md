## DFIR Log Analysis Challenge

Details of investigating Windows Event Logs to identify malicious activity.