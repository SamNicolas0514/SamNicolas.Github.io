## Velociraptor Notes

Useful queries and collection techniques.