## CyberChef Recipes

Common decoding recipes used during analysis.