## MITRE ATT&CK Mapping

Mapping BTLO challenge techniques to MITRE.