# Blue Team Level One (BTLO) Portfolio

This portfolio contains write-ups and documentation of hands-on challenges completed during the BTLO certification.